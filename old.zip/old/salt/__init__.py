from salt.salt import SALT

salt = SALT()