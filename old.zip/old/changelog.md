# Changelog


## Version 0.00 - 2023-10-01
- Created changelog report
- Added core app with WSGI compatibility
- Implemented request handlers
- Added routing with simple route and parameters
- Duplicate Route handler
- Class base handler
